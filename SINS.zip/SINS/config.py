RSS_FEEDS = {
    #Internatinoal Sources
    "BBC": "http://feeds.bbci.co.uk/news/rss.xml",
    "Reuters": "https://feeds.reuters.com/reuters/topNews",
    "TechCrunch": "https://techcrunch.com/feed/",
    #Indian Sources
    "The Hindu":"https://www.thehindu.com/news/national/feeder/default.rss",
    "Indian Express":"https://indianexpress.com/feed/",
    "NDTV":"https://feeds.feedburner.com/ndtvnews-top-stories",
    #Finance
    "MoneyControl":"https://www.moneycontrol.com/rss/latestnews.xml"
}
